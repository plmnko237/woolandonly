(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[601],{4716:function(r,e,n){Promise.resolve().then(n.bind(n,3707))},3707:function(r,e,n){"use strict";n.r(e),n.d(e,{default:function(){return Error}});var t=n(7437);function Error(r){let{error:e,reset:n}=r;return(0,t.jsxs)("div",{className:"list-item",children:[(0,t.jsx)("h2",{className:"loading",children:"❗Error❗"}),(0,t.jsx)("p",{children:(0,t.jsx)("button",{className:"errorBtn",onClick:()=>{n()},children:"다시 시도"})})]})}},622:function(r,e,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2265),o=Symbol.for("react.element"),s=Symbol.for("react.fragment"),i=Object.prototype.hasOwnProperty,c=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,u={key:!0,ref:!0,__self:!0,__source:!0};function q(r,e,n){var t,s={},l=null,f=null;for(t in void 0!==n&&(l=""+n),void 0!==e.key&&(l=""+e.key),void 0!==e.ref&&(f=e.ref),e)i.call(e,t)&&!u.hasOwnProperty(t)&&(s[t]=e[t]);if(r&&r.defaultProps)for(t in e=r.defaultProps)void 0===s[t]&&(s[t]=e[t]);return{$$typeof:o,type:r,key:l,ref:f,props:s,_owner:c.current}}e.Fragment=s,e.jsx=q,e.jsxs=q},7437:function(r,e,n){"use strict";r.exports=n(622)}},function(r){r.O(0,[971,472,744],function(){return r(r.s=4716)}),_N_E=r.O()}]);