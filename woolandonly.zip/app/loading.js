export default function Loading() {
  return (
    <div className="list-item">
      <h2 className="loading">⏳로딩중</h2>
    </div>
  );
}
