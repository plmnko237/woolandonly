import Image from "next/image";
import styles from "./page.module.css";
import { MongoClient } from "mongodb";
import { connectDB } from "@/util/database";
export const revalidate = 60; //60초마다 캐싱

export default async function Home() {
  const db = (await connectDB).db("woolandonly");
  let result = await db.collection("post").find().toArray();

  return <div>메인페이지</div>;
}
