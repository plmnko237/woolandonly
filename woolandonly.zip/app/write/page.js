export default function Write() {
  let nowDay = new Date();
  nowDay =
    nowDay.getFullYear() +
    "-" +
    (nowDay.getMonth() + 1) +
    "-" +
    nowDay.getDate();
  return (
    <div className="detail-bg">
      <div className="detail-con">
        <h3>글쓰기</h3>
        <form action="/api/write" method="POST">
          <div className="write-tit">
            <span>제목 : </span>
            <input
              type="text"
              name="title"
              placeholder="제목을 입력하세요."
              className="title"
              required
              autoFocus
            ></input>
          </div>
          <div className="write-con">
            <textarea
              name="content"
              placeholder="내용을 입력하세요."
              required
            ></textarea>
          </div>
          <input
            type="text"
            name="date"
            value={nowDay}
            style={{ display: "none" }}
          />
          <button type="submit" className="btn1">
            작성완료
          </button>
        </form>
      </div>
    </div>
  );
}
