import { connectDB } from "@/util/database.js";
import { ObjectId } from "mongodb";

export default async function handler(request, answer) {
  if (request.method == "POST") {
    try {
      const db = (await connectDB).db("woolandonly");
      let result = await db
        .collection("post")
        .deleteOne({ _id: new ObjectId(request.body) });
      console.log(result);
      answer.status(200).json("처리완료");
    } catch (error) {
      answer.status(500).json({ error: error.message });
    }
  }
}
